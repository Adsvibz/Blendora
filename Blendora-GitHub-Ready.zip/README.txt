Blendora
1) ارفع كل ملفات المشروع (مع فولدر .github) على repository جديد في GitHub.
2) تبويب Actions > Build APK > استنى ~5 دقايق.
3) نزّل artifact باسم Blendora-APK وثبّت app-debug.apk.
