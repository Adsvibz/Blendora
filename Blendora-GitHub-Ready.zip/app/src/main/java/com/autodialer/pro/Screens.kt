@file:OptIn(ExperimentalMaterial3Api::class)

package com.autodialer.pro

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

// ======================= dialogs =======================
@Composable
fun MenuItem(text: String, danger: Boolean = false, onClick: () -> Unit) =
    DropdownMenuItem(text = { Text(text, style = Ty.body, color = if (danger) B.bad else B.ink) }, onClick = onClick)

@Composable
fun Labeled(label: String, content: @Composable () -> Unit) =
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { FieldLabel(label); content() }

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    BlendDialog(title, onDismiss, "حفظ", { if (t.isNotBlank()) onOk(t.trim()) }) {
        Labeled("الاسم") { BlendField(t, { t = it }, placeholder = "مثال: عملاء أكتوبر") }
    }
}

@Composable
fun EntryDialog(initial: Entry?, onDismiss: () -> Unit, onDelete: (() -> Unit)?, onSave: (String, String) -> Unit) {
    var n by remember { mutableStateOf(initial?.name ?: "") }
    var p by remember { mutableStateOf(initial?.number ?: "") }
    BlendDialog(if (initial == null) "إضافة رقم" else "تعديل الرقم", onDismiss, "حفظ",
        { if (cleanNumber(p).length >= 3) onSave(n, p) }) {
        Labeled("الاسم (اختياري)") { BlendField(n, { n = it }) }
        Labeled("رقم الموبايل") { BlendField(p, { p = it }, placeholder = "010…", keyboard = KeyboardType.Phone, ltr = true) }
        if (onDelete != null) SoftButton("حذف الرقم", onDelete, Modifier.fillMaxWidth(), danger = true)
    }
}

@Composable
fun BulkDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    BlendDialog("لصق أرقام", onDismiss, "إضافة", { onAdd(t) }) {
        Text("رقم في كل سطر، أو بصيغة: الاسم,الرقم", style = Ty.small, color = B.muted)
        BlendField(t, { t = it }, placeholder = "الصق الأرقام هنا", singleLine = false, minLines = 6, maxLines = 10)
    }
}

@Composable
fun ConfirmDialog(text: String, onDismiss: () -> Unit, onOk: () -> Unit) =
    BlendDialog(null, onDismiss, "تأكيد", onOk, danger = true) { Text(text, style = Ty.h3, color = B.ink) }

@Composable
fun ContactsDialog(onDismiss: () -> Unit, onAdd: (List<Pair<String, String>>) -> Unit) {
    val ctx = LocalContext.current
    val all = remember { loadContacts(ctx) }
    var q by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    val shown = all.filter { q.isBlank() || it.first.contains(q, true) || it.second.contains(q) }
    BlendDialog("جهات الاتصال", onDismiss, if (sel.isEmpty()) "إضافة" else "إضافة (${sel.size})", { onAdd(all.filter { it.second in sel }) }) {
        BlendField(q, { q = it }, placeholder = "بحث بالاسم أو الرقم",
            leading = { Ic(Icons.Default.Search, B.muted, 20.dp) })
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val link = Ty.small.copy(fontWeight = FontWeight.SemiBold)
            Text("تحديد الكل", style = link, color = B.brand,
                modifier = Modifier.clip(CircleShape).clickable { sel.clear(); sel.addAll(shown.map { it.second }) }.padding(horizontal = 10.dp, vertical = 6.dp))
            Text("مسح", style = link, color = B.brand,
                modifier = Modifier.clip(CircleShape).clickable { sel.clear() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        LazyColumn(Modifier.height(300.dp)) {
            items(shown, key = { it.second }) { (n, num) ->
                Row(Modifier.fillMaxWidth().clickable { if (num in sel) sel.remove(num) else sel.add(num) }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    CheckDot(num in sel)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(n.ifBlank { num }, style = Ty.body, color = B.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (n.isNotBlank()) NumText(num, style = Ty.small, color = B.muted)
                    }
                }
            }
        }
    }
}

// ======================= lists =======================
@Composable
fun Monogram(name: String, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(14.dp)).background(B.brandSoft), Alignment.Center) {
        Text(name.trim().take(1), style = Ty.h3, color = B.brand)
    }
}

@Composable
fun ListsScreen() {
    var showNew by remember { mutableStateOf(false) }
    val sub = if (Store.lists.isEmpty()) "Blendora" else
        countLabel(Store.lists.size, "قائمة واحدة", "قائمتان", "قوائم", "قائمة") + "، " + Store.lists.sumOf { it.entries.size } + " رقم"
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("قوائم الاتصال", sub, actions = {
            RoundBtn({ showNew = true }, filled = true) { Ic(Icons.Default.Add, B.onBrand) }
        })
        if (Store.lists.isEmpty()) {
            EmptyState("ابدأ بأول قائمة", "اجمع أرقامك في قائمة، ثم شغّل الحملة بضغطة واحدة.", "قائمة جديدة") { showNew = true }
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Store.lists, key = { it.id }) { l ->
                    val total = l.entries.size
                    val ok = l.entries.count { it.status == St.ANSWERED || it.status == St.DONE }
                    val shape = RoundedCornerShape(20.dp)
                    Row(Modifier.fillMaxWidth().clip(shape).background(B.surface).border(1.dp, B.hairline, shape)
                        .clickable { Store.selectedListId = l.id }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Monogram(l.name)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(l.name, style = Ty.h3, color = B.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("$total رقم" + if (ok > 0) "، $ok تم الرد" else "", style = Ty.small, color = B.muted)
                        }
                        if (total > 0) Ring(ok / total.toFloat(), Modifier.size(46.dp), stroke = 4.dp) {
                            NumText("${ok * 100 / total}%", style = Ty.micro, color = B.muted)
                        }
                    }
                }
            }
        }
    }
    if (showNew) NameDialog("قائمة جديدة", "", { showNew = false }) { n ->
        Store.selectedListId = Store.addList(n); showNew = false
    }
}

@Composable
fun ListDetail(listId: String, act: MainActivity) {
    val list = Store.lists.find { it.id == listId }
    if (list == null) { LaunchedEffect(Unit) { Store.selectedListId = null }; return }
    val ctx = LocalContext.current
    val b = B
    BackHandler { Store.selectedListId = null }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Entry?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull() ?: ""
            val n = Store.addEntries(listId, parseLines(text))
            Toast.makeText(ctx, "تمت إضافة $n رقم", Toast.LENGTH_SHORT).show()
        }
    }
    val shown = list.entries.filter { query.isBlank() || it.name.contains(query, true) || it.number.contains(query) }
    val ok = list.entries.count { it.status == St.ANSWERED || it.status == St.DONE }
    val na = list.entries.count { it.status == St.NO_ANSWER }
    val fl = list.entries.count { it.status == St.FAILED }
    val pend = list.entries.size - ok - na - fl

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(list.name, "${list.entries.size} رقم",
                leading = { RoundBtn({ Store.selectedListId = null }) { Ic(Icons.AutoMirrored.Filled.ArrowBack, b.ink) } },
                actions = {
                    Box {
                        RoundBtn({ menu = true }) { Ic(Icons.Default.MoreVert, b.ink) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, modifier = Modifier.background(b.surface)) {
                            MenuItem("إعادة تسمية القائمة") { menu = false; dlg = "rename" }
                            MenuItem("إعادة تعيين الحالات") { menu = false; Store.resetStatuses(listId) }
                            MenuItem("حذف الأرقام المكررة") {
                                menu = false
                                Toast.makeText(ctx, "تم حذف ${Store.dedupe(listId)} رقم مكرر", Toast.LENGTH_SHORT).show()
                            }
                            MenuItem("حذف من تم الرد عليهم") { menu = false; Store.removeAnswered(listId) }
                            MenuItem("مشاركة تقرير القائمة") { menu = false; shareText(ctx, Store.listReport(list)) }
                            MenuItem("مسح كل الأرقام", danger = true) { menu = false; dlg = "clear" }
                            MenuItem("حذف القائمة", danger = true) { menu = false; dlg = "delete" }
                        }
                    }
                })
            if (list.entries.isNotEmpty()) Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                StackBar(listOf(ok to b.ok, na to b.warn, fl to b.bad, pend to b.hairline))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Legend("تم الرد", ok, b.ok); Legend("لم يُرد", na, b.warn); Legend("فشل", fl, b.bad)
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("إضافة رقم", { dlg = "add" })
                Pill("لصق أرقام", { dlg = "bulk" })
                Pill("استيراد ملف", { importer.launch(arrayOf("*/*")) })
                Pill("من جهات الاتصال", { act.ensureContacts { dlg = "contacts" } })
            }
            BlendField(query, { query = it }, Modifier.padding(horizontal = 20.dp), "بحث بالاسم أو الرقم",
                leading = { Ic(Icons.Default.Search, b.muted, 20.dp) })
            Spacer(Modifier.height(8.dp))
            Box(Modifier.weight(1f)) {
                if (list.entries.isEmpty()) EmptyState("القائمة فارغة", "أضف أرقامًا يدويًا، أو الصق قائمة، أو استورد ملفًا.")
                else LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
                    items(shown, key = { it.id }) { e ->
                        Row(Modifier.fillMaxWidth().clickable { editing = e }.padding(horizontal = 20.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(40.dp).clip(CircleShape).background(b.sunken), Alignment.Center) {
                                if (e.name.isNotBlank()) Text(e.name.trim().take(1), style = Ty.h3, color = b.muted)
                                else Ic(Icons.Default.Person, b.muted, 20.dp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                if (e.name.isNotBlank()) {
                                    Text(e.name, style = Ty.h3, color = b.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    NumText(e.number, style = Ty.small, color = b.muted)
                                } else NumText(e.number, style = Ty.h3, color = b.ink)
                            }
                            if (e.status != St.PENDING) StatusPill(e.status)
                        }
                        Rule(20.dp)
                    }
                }
            }
        }
        if (list.entries.isNotEmpty()) PrimaryButton("ابدأ الحملة", { act.startCampaign(listId) },
            Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp).shadow(12.dp, CircleShape, spotColor = b.brand.copy(alpha = 0.4f)),
            icon = { Ic(Icons.Default.PlayArrow, b.onBrand) })
    }

    when (dlg) {
        "add" -> EntryDialog(null, { dlg = "" }, null) { n, num -> Store.addEntries(listId, listOf(n to num)); dlg = "" }
        "bulk" -> BulkDialog({ dlg = "" }) { t ->
            val n = Store.addEntries(listId, parseLines(t))
            Toast.makeText(ctx, "تمت إضافة $n رقم", Toast.LENGTH_SHORT).show(); dlg = ""
        }
        "contacts" -> ContactsDialog({ dlg = "" }) { sel ->
            val n = Store.addEntries(listId, sel)
            Toast.makeText(ctx, "تمت إضافة $n رقم", Toast.LENGTH_SHORT).show(); dlg = ""
        }
        "rename" -> NameDialog("إعادة تسمية", list.name, { dlg = "" }) { n ->
            Store.updateList(listId) { it.copy(name = n) }; dlg = ""
        }
        "clear" -> ConfirmDialog("حذف كل الأرقام من القائمة؟", { dlg = "" }) {
            Store.updateList(listId) { it.copy(entries = emptyList()) }; dlg = ""
        }
        "delete" -> ConfirmDialog("حذف القائمة بكل أرقامها؟", { dlg = "" }) {
            dlg = ""; Store.deleteList(listId); Store.selectedListId = null
        }
    }
    editing?.let { e ->
        EntryDialog(e, { editing = null }, { Store.deleteEntry(listId, e.id); editing = null }) { n, num ->
            Store.updateEntry(listId, e.id) { it.copy(name = n.trim(), number = cleanNumber(num)) }; editing = null
        }
    }
}

// ======================= campaign =======================
@Composable
private fun StatCell(label: String, v: Int, color: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        NumText("$v", style = Ty.h2, color = color)
        Text(label, style = Ty.small, color = B.muted)
    }
}

@Composable
private fun Control(label: String, size: Dp, bg: Color, border: Color, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(Modifier.width(92.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.height(72.dp), Alignment.Center) {
            Box(Modifier.size(size).clip(CircleShape).background(bg).border(1.dp, border, CircleShape).clickable(onClick = onClick),
                Alignment.Center) { icon() }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = Ty.micro, color = B.muted, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = Ty.body, color = B.muted)
        Text(value, style = Ty.body.copy(fontWeight = FontWeight.Medium), color = B.ink)
    }
}

@Composable
fun CampaignScreen(act: MainActivity) {
    val c = Store.camp
    val ctx = LocalContext.current
    val b = B
    val active = c.status == CS.RUNNING || c.status == CS.PAUSED || c.status == CS.WAITING
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { now = System.currentTimeMillis(); delay(500) } }
    val reduce = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    val showHero = active || c.status == CS.FINISHED

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("الحملة", if (showHero) c.listName else "اختر قائمة وابدأ")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)) {

            if (showHero) {
                val p = if (c.total == 0) 0f else c.done / c.total.toFloat()
                val calling = c.status == CS.RUNNING && c.currentNumber.isNotEmpty()
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Ring(p, Modifier.size(224.dp), stroke = 14.dp, pulse = calling && !reduce) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            NumText("${c.done}", style = Ty.display, color = b.ink)
                            Text("من ${c.total}", style = Ty.small, color = b.muted)
                        }
                    }
                    val title = when (c.status) {
                        CS.PAUSED -> "متوقفة مؤقتًا"
                        CS.WAITING -> "بانتظار ساعات السماح"
                        CS.FINISHED -> c.message.replace("✓", "").trim()
                        else -> if (calling) "جارٍ الاتصال" else "استعداد"
                    }
                    Text(title, style = Ty.h2, color = b.ink, textAlign = TextAlign.Center)
                    if (calling) Group {
                        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (c.currentName.isNotEmpty()) Text(c.currentName, style = Ty.body, color = b.muted)
                            NumText(c.currentNumber, style = Ty.h2, color = b.ink)
                        }
                    } else {
                        val detail = when {
                            c.status == CS.RUNNING && c.nextAt > now -> "${c.message} ${(c.nextAt - now + 999) / 1000} ث"
                            c.status == CS.WAITING -> c.message
                            else -> ""
                        }
                        if (detail.isNotEmpty()) Text(detail, style = Ty.body, color = b.muted, textAlign = TextAlign.Center)
                    }
                    if (c.loops > 1 && c.status != CS.FINISHED) Text("الجولة ${c.loop} من ${c.loops}", style = Ty.small, color = b.muted)
                }
                Group {
                    Row(Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                        StatCell("تم الرد", c.answered, b.ok, Modifier.weight(1f))
                        Box(Modifier.width(1.dp).height(36.dp).background(b.hairline).align(Alignment.CenterVertically))
                        StatCell("لم يُرد", c.noAnswer, b.warn, Modifier.weight(1f))
                        Box(Modifier.width(1.dp).height(36.dp).background(b.hairline).align(Alignment.CenterVertically))
                        StatCell("فشل", c.failed, b.bad, Modifier.weight(1f))
                    }
                }
            }

            if (active) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Control("إنهاء المكالمة", 56.dp, b.surface, b.hairline, { DialerService.send(ctx, DialerService.ACT_SKIP) }) {
                        Glyph(Gl.SKIP, b.ink)
                    }
                    if (c.status == CS.PAUSED)
                        Control("استئناف", 72.dp, b.brand, b.brand, { DialerService.send(ctx, DialerService.ACT_RESUME) }) {
                            Ic(Icons.Default.PlayArrow, b.onBrand, 34.dp)
                        }
                    else
                        Control("إيقاف مؤقت", 72.dp, b.brand, b.brand, { DialerService.send(ctx, DialerService.ACT_PAUSE) }) {
                            Glyph(Gl.PAUSE, b.onBrand, 30.dp)
                        }
                    Control("إيقاف", 56.dp, b.bad.copy(alpha = 0.12f), Color.Transparent, { DialerService.send(ctx, DialerService.ACT_STOP) }) {
                        Glyph(Gl.STOP, b.bad)
                    }
                }
            } else {
                val sel = Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } } ?: Store.lists.firstOrNull()?.id
                if (Store.lists.isEmpty()) {
                    Group { Text("أنشئ قائمة أولًا من تبويب القوائم.", style = Ty.body, color = b.muted, modifier = Modifier.padding(20.dp)) }
                } else Group {
                    Store.lists.forEachIndexed { i, l ->
                        if (i > 0) Rule()
                        Row(Modifier.fillMaxWidth().clickable { Store.runListId = l.id }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(l.name, style = Ty.h3, color = b.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${l.entries.size} رقم", style = Ty.small, color = b.muted)
                            }
                            CheckDot(l.id == sel)
                        }
                    }
                }
                PrimaryButton("ابدأ الحملة", { sel?.let { act.startCampaign(it) } }, Modifier.fillMaxWidth(), enabled = sel != null,
                    icon = { Ic(Icons.Default.PlayArrow, if (sel != null) b.onBrand else b.muted) })
                val s = Store.cfg
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("الإعدادات الحالية", style = Ty.h3, color = b.ink)
                    Text("تعديل", style = Ty.small.copy(fontWeight = FontWeight.SemiBold), color = b.brand,
                        modifier = Modifier.clip(CircleShape).clickable { Store.tab = 3 }.padding(horizontal = 12.dp, vertical = 6.dp))
                }
                Group {
                    InfoRow("الانتظار بين المكالمات", if (s.randomDelay) "${s.delaySec}–${s.delayMaxSec} ث (عشوائي)" else "${s.delaySec} ث")
                    Rule(); InfoRow("إعادة المحاولة", if (s.retries == 0) "بدون" else "${s.retries} مرات")
                    Rule(); InfoRow("عدد الجولات", "${s.loops}")
                    Rule(); InfoRow("الشريحة", if (s.simIndex < 0) "الافتراضي" else "SIM ${s.simIndex + 1}")
                    if (s.maxCallSec > 0) { Rule(); InfoRow("حد المكالمة", "${s.maxCallSec} ث") }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ======================= log =======================
@Composable
fun LogScreen() {
    val ctx = LocalContext.current
    val b = B
    var f by remember { mutableIntStateOf(-1) }
    var confirm by remember { mutableStateOf(false) }
    val shown = Store.log.filter { f == -1 || it.status == f }
    val groups = shown.groupBy { dayKey(it.time) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("السجل", countLabel(Store.log.size, "مكالمة واحدة", "مكالمتان", "مكالمات", "مكالمة"), actions = {
            RoundBtn({ if (shown.isNotEmpty()) shareText(ctx, Store.logReport(shown)) }) { Ic(Icons.Default.Share, b.ink, 20.dp) }
            RoundBtn({ if (Store.log.isNotEmpty()) confirm = true }) { Ic(Icons.Default.Delete, b.ink, 20.dp) }
        })
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(-1 to "الكل", St.ANSWERED to "تم الرد", St.NO_ANSWER to "لم يُرد", St.FAILED to "فشل", St.DONE to "انتهت")
                .forEach { (k, n) -> Pill(n, { f = k }, selected = f == k) }
        }
        if (shown.isEmpty()) EmptyState("لا يوجد سجل بعد", "ستظهر هنا كل مكالمة بعد انتهائها.")
        else LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            groups.forEach { (k, rows) ->
                item(key = "day$k") {
                    Text(dayLabel(rows.first().time), style = Ty.small.copy(fontWeight = FontWeight.SemiBold), color = b.muted,
                        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 6.dp))
                }
                items(rows) { l ->
                    val c = statusColor(l.status)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(c.copy(alpha = 0.12f)), Alignment.Center) {
                            when (l.status) {
                                St.FAILED -> Ic(Icons.Default.Close, c, 20.dp)
                                St.NO_ANSWER -> Ic(Icons.Default.Call, c, 18.dp)
                                else -> Ic(Icons.Default.Check, c, 20.dp)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            if (l.name.isNotBlank()) Text(l.name, style = Ty.h3, color = b.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            else NumText(l.number, style = Ty.h3, color = b.ink)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (l.name.isNotBlank()) NumText(l.number, style = Ty.small, color = b.muted)
                                NumText(fmtClock(l.time), style = Ty.small, color = b.muted)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            StatusPill(l.status)
                            if (l.duration > 0) NumText(fmtDur(l.duration), style = Ty.micro, color = b.muted)
                        }
                    }
                    Rule(20.dp)
                }
            }
        }
    }
    if (confirm) ConfirmDialog("مسح كل السجل؟", { confirm = false }) { Store.clearLog(); confirm = false }
}

// ======================= settings =======================
@Composable
fun SliderRow(title: String, value: Int, min: Int, max: Int, suffix: String, zeroText: String? = null,
              sub: String? = null, onChange: (Int) -> Unit) {
    val b = B
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = Ty.body, color = b.ink, modifier = Modifier.weight(1f))
            Text(if (value == 0 && zeroText != null) zeroText else (if (suffix.startsWith(":")) "$value$suffix" else "$value $suffix").trim(),
                style = Ty.small.copy(fontWeight = FontWeight.SemiBold, fontFeatureSettings = "tnum"), color = b.brand)
        }
        if (sub != null) Text(sub, style = Ty.small, color = b.muted)
        Slider(value = value.toFloat(), onValueChange = { onChange(it.roundToInt()) }, valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(thumbColor = b.brand, activeTrackColor = b.brand, inactiveTrackColor = b.sunken))
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val b = B
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Ty.body, color = b.ink)
            if (sub != null) Text(sub, style = Ty.small, color = b.muted)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(
            checkedThumbColor = b.onBrand, checkedTrackColor = b.brand, checkedBorderColor = b.brand,
            uncheckedThumbColor = b.surface, uncheckedTrackColor = b.hairline, uncheckedBorderColor = b.hairline))
    }
}

@Composable
fun SettingsScreen() {
    val c = Store.cfg
    val ctx = LocalContext.current
    val b = B
    fun up(f: (Cfg) -> Cfg) = Store.updateCfg(f)

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("الإعدادات", "تحكم في سلوك الحملة")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {

            SectionTitle("التوقيت")
            Group {
                SliderRow("الانتظار بين المكالمات", c.delaySec, 0, 120, "ث") { v -> up { it.copy(delaySec = v) } }
                Rule(); SwitchRow("انتظار عشوائي", "مدة عشوائية بين الحدّين لتبدو طبيعية", c.randomDelay) { v -> up { it.copy(randomDelay = v) } }
                if (c.randomDelay) { Rule(); SliderRow("أقصى مدة انتظار", c.delayMaxSec, 1, 300, "ث") { v -> up { it.copy(delayMaxSec = v) } } }
                Rule(); SliderRow("عدّاد قبل بدء الحملة", c.startCountdown, 0, 30, "ث", "فوري") { v -> up { it.copy(startCountdown = v) } }
                Rule(); SliderRow("إنهاء المكالمة تلقائيًا بعد", c.maxCallSec, 0, 600, "ث", "معطّل",
                    "يقطع الرنين الطويل ويحدد مدة قصوى لكل مكالمة") { v -> up { it.copy(maxCallSec = v) } }
            }

            SectionTitle("الحملة")
            Group {
                SliderRow("إعادة المحاولة لمن لم يرد", c.retries, 0, 5, "مرات", "بدون") { v -> up { it.copy(retries = v) } }
                Rule(); SliderRow("عدد الجولات (تكرار القائمة)", c.loops, 1, 20, "") { v -> up { it.copy(loops = v) } }
                Rule(); SwitchRow("ترتيب عشوائي", "خلط ترتيب الأرقام عند البدء", c.shuffle) { v -> up { it.copy(shuffle = v) } }
                Rule(); SwitchRow("تخطّي من تم الرد عليهم", "لا يتصل بأرقام ردّت سابقًا", c.skipAnswered) { v -> up { it.copy(skipAnswered = v) } }
                Rule(); SwitchRow("اكتشاف الرد من سجل المكالمات", "أدق طريقة لمعرفة (رد / لم يرد)", c.useCallLog) { v -> up { it.copy(useCallLog = v) } }
            }

            SectionTitle("الاتصال")
            Group {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الشريحة المستخدمة", style = Ty.body, color = b.ink)
                    Segmented(listOf("الافتراضي", "SIM 1", "SIM 2"), c.simIndex + 1) { i -> up { it.copy(simIndex = i - 1) } }
                }
                Rule()
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("كود الدولة (اختياري)", style = Ty.body, color = b.ink)
                    BlendField(c.countryCode, { t -> up { s -> s.copy(countryCode = t.filter { ch -> ch.isDigit() }) } },
                        placeholder = "20", keyboard = KeyboardType.Number, ltr = true)
                    Text("لو كتبته، الرقم 010… يتحول إلى +2010…", style = Ty.small, color = b.muted)
                }
            }

            SectionTitle("ساعات السماح بالاتصال")
            Group {
                SwitchRow("تحديد وقت للعمل", "الحملة تنتظر خارج هذه الساعات", c.quietEnabled) { v -> up { it.copy(quietEnabled = v) } }
                if (c.quietEnabled) {
                    Rule(); SliderRow("من الساعة", c.quietFrom, 0, 23, ":00") { v -> up { it.copy(quietFrom = v) } }
                    Rule(); SliderRow("إلى الساعة", c.quietTo, 0, 23, ":00") { v -> up { it.copy(quietTo = v) } }
                }
            }

            SectionTitle("المظهر والتنبيهات")
            Group {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("السمة", style = Ty.body, color = b.ink)
                    Segmented(listOf("تلقائي", "فاتح", "داكن"), c.themeMode) { i -> up { it.copy(themeMode = i) } }
                }
                Rule(); SwitchRow("إبقاء الشاشة مفتوحة أثناء الحملة", null, c.keepScreenOn) { v -> up { it.copy(keepScreenOn = v) } }
                Rule(); SwitchRow("اهتزاز عند انتهاء الحملة", null, c.vibrateOnFinish) { v -> up { it.copy(vibrateOnFinish = v) } }
            }

            SectionTitle("الصلاحيات والتشغيل في الخلفية")
            Group {
                val perms = listOf(
                    "الاتصال" to Manifest.permission.CALL_PHONE,
                    "حالة الهاتف" to Manifest.permission.READ_PHONE_STATE,
                    "سجل المكالمات" to Manifest.permission.READ_CALL_LOG,
                    "إنهاء المكالمات" to Manifest.permission.ANSWER_PHONE_CALLS,
                    "جهات الاتصال" to Manifest.permission.READ_CONTACTS
                )
                perms.forEachIndexed { i, (n, p) ->
                    if (i > 0) Rule()
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(n, style = Ty.body, color = b.ink)
                        if (ctx.has(p)) Tag("ممنوحة", b.ok) else Tag("غير ممنوحة", b.bad)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SoftButton("فتح إعدادات التطبيق", {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))
                }, Modifier.fillMaxWidth())
                SoftButton("استثناء من توفير البطارية", {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }, Modifier.fillMaxWidth())
            }

            Column(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                BlendMark(32.dp)
                Text("Blendora 3.0", style = Ty.small, color = b.muted)
            }
        }
    }
}
