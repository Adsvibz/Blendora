package com.autodialer.pro

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {

    private var afterPerms: (() -> Unit)? = null
    private var afterContacts: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE)) afterPerms?.invoke()
            else Toast.makeText(this, "صلاحيات الاتصال وحالة الهاتف مطلوبة لتشغيل الحملة", Toast.LENGTH_LONG).show()
            afterPerms = null
        }

    private val contactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) afterContacts?.invoke()
            afterContacts = null
        }

    fun ensureContacts(after: () -> Unit) {
        if (has(Manifest.permission.READ_CONTACTS)) after()
        else { afterContacts = after; contactsLauncher.launch(Manifest.permission.READ_CONTACTS) }
    }

    fun startCampaign(listId: String) {
        val st = Store.camp.status
        if (st == CS.RUNNING || st == CS.PAUSED || st == CS.WAITING) {
            Toast.makeText(this, "توجد حملة جارية بالفعل", Toast.LENGTH_SHORT).show()
            Store.tab = 1
            return
        }
        val need = mutableListOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !has(it) }
        val go = {
            Store.runListId = listId
            Store.tab = 1
            DialerService.send(this, DialerService.ACT_START, listId)
        }
        if (missing.isEmpty()) go() else { afterPerms = go; permLauncher.launch(missing.toTypedArray()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                AppTheme { Root(this@MainActivity) }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Root(act: MainActivity) {
    val keep = Store.cfg.keepScreenOn && (Store.camp.status == CS.RUNNING || Store.camp.status == CS.WAITING)
    val ctx = LocalContext.current as Activity
    LaunchedEffect(keep) {
        if (keep) ctx.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else ctx.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    BackHandler(enabled = Store.tab != 0) { Store.tab = 0 }
    val imeUp = WindowInsets.isImeVisible
    Column(Modifier.fillMaxSize().background(B.canvas).imePadding()) {
        Box(Modifier.weight(1f).fillMaxWidth().statusBarsPadding()) {
            Crossfade(targetState = Store.tab to Store.selectedListId, animationSpec = tween(160)) { (tab, sel) ->
                when (tab) {
                    0 -> if (sel == null) ListsScreen() else ListDetail(sel, act)
                    1 -> CampaignScreen(act)
                    2 -> LogScreen()
                    else -> SettingsScreen()
                }
            }
        }
        if (!imeUp) BottomBar(Store.tab) { Store.tab = it }
    }
}
