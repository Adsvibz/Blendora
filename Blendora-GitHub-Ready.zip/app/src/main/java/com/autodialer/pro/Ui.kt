package com.autodialer.pro

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// ======================= primitives =======================
@Composable
fun Ic(v: ImageVector, tint: Color, size: Dp = 22.dp) = Icon(v, null, Modifier.size(size), tint = tint)

@Composable
fun Rule(inset: Dp = 16.dp) = Box(Modifier.fillMaxWidth().padding(horizontal = inset).height(1.dp).background(B.hairline))

/** The Blendora mark: two translucent circles that blend where they meet. */
@Composable
fun BlendMark(size: Dp) {
    val b = B
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension * 0.30f
        drawCircle(b.brand.copy(alpha = 0.92f), r, Offset(this.size.width * 0.38f, this.size.height / 2))
        drawCircle(b.iris.copy(alpha = 0.80f), r, Offset(this.size.width * 0.62f, this.size.height / 2))
    }
}

enum class Gl { LIST, CLOCK, PAUSE, STOP, SKIP }

/** Small filled glyphs drawn in-code (the core icon set has no pause / stop / skip / clock). */
@Composable
fun Glyph(g: Gl, tint: Color, size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension / 24f
        when (g) {
            Gl.LIST -> {
                for (y in listOf(6.5f, 12f, 17.5f)) {
                    drawCircle(tint, 1.5f * s, Offset(5.5f * s, y * s))
                    drawRoundRect(tint, Offset(9f * s, (y - 1.3f) * s), Size(10f * s, 2.6f * s), CornerRadius(1.3f * s))
                }
            }
            Gl.PAUSE -> {
                drawRoundRect(tint, Offset(6f * s, 5f * s), Size(4f * s, 14f * s), CornerRadius(1.5f * s))
                drawRoundRect(tint, Offset(14f * s, 5f * s), Size(4f * s, 14f * s), CornerRadius(1.5f * s))
            }
            Gl.STOP -> drawRoundRect(tint, Offset(6f * s, 6f * s), Size(12f * s, 12f * s), CornerRadius(2.5f * s))
            Gl.SKIP -> {
                val p = Path().apply {
                    moveTo(6f * s, 5.5f * s); lineTo(15.5f * s, 12f * s); lineTo(6f * s, 18.5f * s); close()
                }
                drawPath(p, tint)
                drawRoundRect(tint, Offset(16.5f * s, 5f * s), Size(2.5f * s, 14f * s), CornerRadius(1.2f * s))
            }
            Gl.CLOCK -> {
                val p = Path().apply {
                    fillType = PathFillType.EvenOdd
                    addOval(Rect(3f * s, 3f * s, 21f * s, 21f * s))
                    moveTo(11f * s, 7f * s); lineTo(13f * s, 7f * s); lineTo(13f * s, 11.2f * s)
                    lineTo(16.4f * s, 13.2f * s); lineTo(15.4f * s, 14.9f * s); lineTo(11f * s, 12.3f * s); close()
                }
                drawPath(p, tint)
            }
        }
    }
}

// ======================= layout =======================
@Composable
fun ScreenHeader(
    title: String, subtitle: String? = null, leading: (@Composable () -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (leading != null) { leading(); Spacer(Modifier.width(12.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, style = Ty.h1, color = B.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, style = Ty.small, color = B.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = actions)
    }
}

@Composable
fun RoundBtn(onClick: () -> Unit, filled: Boolean = false, content: @Composable () -> Unit) {
    val b = B
    Box(Modifier.size(42.dp).clip(CircleShape).background(if (filled) b.brand else b.surface)
        .border(1.dp, if (filled) b.brand else b.hairline, CircleShape).clickable(onClick = onClick), Alignment.Center) { content() }
}

@Composable
fun Group(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(modifier.fillMaxWidth().clip(shape).background(B.surface).border(1.dp, B.hairline, shape), content = content)
}

@Composable
fun SectionTitle(text: String) =
    Text(text, style = Ty.small.copy(fontWeight = FontWeight.SemiBold), color = B.muted,
        modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 24.dp, bottom = 8.dp))

@Composable
fun EmptyState(title: String, body: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(40.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(Modifier.size(84.dp).clip(CircleShape).background(B.brandSoft), Alignment.Center) { BlendMark(52.dp) }
        Spacer(Modifier.height(20.dp))
        Text(title, style = Ty.h2, color = B.ink, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(body, style = Ty.body, color = B.muted, textAlign = TextAlign.Center)
        if (action != null) { Spacer(Modifier.height(24.dp)); PrimaryButton(action, onAction) }
    }
}

// ======================= controls =======================
@Composable
fun PrimaryButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    danger: Boolean = false, icon: (@Composable () -> Unit)? = null
) {
    val b = B
    Row(modifier.height(52.dp).clip(CircleShape).background(if (!enabled) b.sunken else if (danger) b.bad else b.brand)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 26.dp),
        Arrangement.Center, Alignment.CenterVertically) {
        if (icon != null) { icon(); Spacer(Modifier.width(8.dp)) }
        Text(text, style = Ty.h3, color = if (enabled) b.onBrand else b.muted, maxLines = 1)
    }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false) {
    val b = B
    Row(modifier.height(52.dp).clip(CircleShape).background(if (danger) b.bad.copy(alpha = 0.12f) else b.sunken)
        .clickable(onClick = onClick).padding(horizontal = 22.dp), Arrangement.Center, Alignment.CenterVertically) {
        Text(text, style = Ty.h3, color = if (danger) b.bad else b.ink, maxLines = 1)
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit, selected: Boolean = false) {
    val b = B
    Box(Modifier.height(38.dp).clip(CircleShape).background(if (selected) b.brand else b.surface)
        .border(1.dp, if (selected) b.brand else b.hairline, CircleShape).clickable(onClick = onClick).padding(horizontal = 16.dp),
        Alignment.Center) {
        Text(text, style = Ty.small.copy(fontWeight = FontWeight.Medium), color = if (selected) b.onBrand else b.ink, maxLines = 1)
    }
}

@Composable
fun Tag(text: String, color: Color) {
    Row(Modifier.clip(CircleShape).background(color.copy(alpha = 0.12f)).padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, style = Ty.micro, color = color, maxLines = 1)
    }
}

@Composable
fun StatusPill(s: Int) = Tag(St.label(s), statusColor(s))

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val b = B
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(b.sunken).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            Box(Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(11.dp))
                .background(if (on) b.raised else Color.Transparent).clickable { onSelect(i) }, Alignment.Center) {
                Text(o, style = Ty.small.copy(fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal),
                    color = if (on) b.ink else b.muted, maxLines = 1)
            }
        }
    }
}

@Composable
fun CheckDot(on: Boolean) {
    val b = B
    Box(Modifier.size(22.dp).clip(CircleShape).background(if (on) b.brand else Color.Transparent)
        .border(1.5.dp, if (on) b.brand else b.hairline, CircleShape), Alignment.Center) {
        if (on) Ic(Icons.Default.Check, b.onBrand, 14.dp)
    }
}

@Composable
fun BlendField(
    value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, placeholder: String = "",
    leading: (@Composable () -> Unit)? = null, keyboard: KeyboardType = KeyboardType.Text, ltr: Boolean = false,
    singleLine: Boolean = true, minLines: Int = 1, maxLines: Int = if (singleLine) 1 else 8
) {
    val b = B
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(b.sunken).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = if (singleLine) Alignment.CenterVertically else Alignment.Top) {
        if (leading != null) { leading(); Spacer(Modifier.width(10.dp)) }
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(placeholder, style = Ty.body, color = b.muted)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = singleLine, minLines = minLines, maxLines = maxLines,
                textStyle = Ty.body.copy(color = b.ink, textDirection = if (ltr) TextDirection.Ltr else TextDirection.Content),
                keyboardOptions = KeyboardOptions(keyboardType = keyboard),
                cursorBrush = SolidColor(b.brand), modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun FieldLabel(text: String) = Text(text, style = Ty.small.copy(fontWeight = FontWeight.Medium), color = B.muted)

@Composable
fun BlendDialog(
    title: String?, onDismiss: () -> Unit, confirm: String?, onConfirm: () -> Unit = {}, danger: Boolean = false,
    cancel: String = "إلغاء", content: @Composable ColumnScope.() -> Unit = {}
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.padding(horizontal = 24.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(B.surface).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (title != null) Text(title, style = Ty.h2, color = B.ink)
            content()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SoftButton(cancel, onDismiss, Modifier.weight(1f))
                if (confirm != null) PrimaryButton(confirm, onConfirm, Modifier.weight(1f), danger = danger)
            }
        }
    }
}

// ======================= data display =======================
@Composable
fun NumText(n: String, modifier: Modifier = Modifier, style: androidx.compose.ui.text.TextStyle = Ty.body, color: Color = Color.Unspecified) {
    Text(n, modifier = modifier, style = style.copy(textDirection = TextDirection.Ltr, fontFeatureSettings = "tnum"), color = color)
}

@Composable
fun Ring(
    progress: Float, modifier: Modifier = Modifier, stroke: Dp = 12.dp, pulse: Boolean = false,
    content: @Composable BoxScope.() -> Unit = {}
) {
    val b = B
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(700), label = "ring")
    Box(modifier, Alignment.Center) {
        if (pulse) Halo(b.brand)
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val box = Size(size.width - w, size.height - w)
            val tl = Offset(w / 2, w / 2)
            drawArc(b.sunken, 0f, 360f, false, tl, box, style = Stroke(w))
            if (p > 0f) rotate(-90f) {
                drawArc(Brush.sweepGradient(listOf(b.brand, b.iris, b.brand)), 0f, 360f * p, false, tl, box,
                    style = Stroke(w, cap = StrokeCap.Round))
            }
        }
        content()
    }
}

@Composable
private fun Halo(color: Color) {
    val t = rememberInfiniteTransition(label = "halo")
    val a by t.animateFloat(0.03f, 0.14f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "a")
    Box(Modifier.fillMaxSize().padding(10.dp).clip(CircleShape).background(color.copy(alpha = a)))
}

@Composable
fun StackBar(parts: List<Pair<Int, Color>>, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(B.hairline),
        horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        parts.filter { it.first > 0 }.forEach { (v, c) -> Box(Modifier.weight(v.toFloat()).fillMaxHeight().background(c)) }
    }
}

@Composable
fun Legend(label: String, n: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text("$label $n", style = Ty.small, color = B.muted, maxLines = 1)
    }
}

private class NavTab(val label: String, val icon: @Composable (Color) -> Unit)

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val b = B
    val items = listOf(
        NavTab("القوائم") { c -> Glyph(Gl.LIST, c) },
        NavTab("الحملة") { c -> Ic(Icons.Default.Call, c) },
        NavTab("السجل") { c -> Glyph(Gl.CLOCK, c) },
        NavTab("الإعدادات") { c -> Ic(Icons.Default.Settings, c) }
    )
    Column(Modifier.fillMaxWidth().background(b.surface)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(b.hairline))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp)) {
            items.forEachIndexed { i, t ->
                val on = selected == i
                Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { onSelect(i) }.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.height(30.dp).width(58.dp).clip(CircleShape).background(if (on) b.brandSoft else Color.Transparent),
                        Alignment.Center) { t.icon(if (on) b.brand else b.muted) }
                    Text(t.label, style = Ty.micro, color = if (on) b.brand else b.muted, maxLines = 1)
                }
            }
        }
    }
}
