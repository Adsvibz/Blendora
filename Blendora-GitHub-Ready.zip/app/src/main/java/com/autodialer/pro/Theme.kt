package com.autodialer.pro

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/** Blendora design tokens. One palette, two moods. Everything in the UI reads from here. */
@Immutable
class Blend(
    val dark: Boolean,
    val canvas: Color, val surface: Color, val raised: Color, val sunken: Color,
    val ink: Color, val muted: Color, val hairline: Color,
    val brand: Color, val onBrand: Color, val brandSoft: Color, val iris: Color,
    val ok: Color, val warn: Color, val bad: Color, val info: Color
)

private val BlendLight = Blend(
    dark = false,
    canvas = Color(0xFFF4F6F8), surface = Color(0xFFFFFFFF), raised = Color(0xFFFFFFFF), sunken = Color(0xFFEBEFF3),
    ink = Color(0xFF14202B), muted = Color(0xFF66737F), hairline = Color(0xFFE3E8ED),
    brand = Color(0xFF17655F), onBrand = Color(0xFFFFFFFF), brandSoft = Color(0xFFDDEFEC), iris = Color(0xFF6350C8),
    ok = Color(0xFF2E8F63), warn = Color(0xFFA8650E), bad = Color(0xFFC94242), info = Color(0xFF3B6FD4)
)

private val BlendDark = Blend(
    dark = true,
    canvas = Color(0xFF0B1013), surface = Color(0xFF131A1F), raised = Color(0xFF27333B), sunken = Color(0xFF1B242B),
    ink = Color(0xFFE8EEF1), muted = Color(0xFF8D99A4), hairline = Color(0xFF232D34),
    brand = Color(0xFF5CCDBC), onBrand = Color(0xFF06211E), brandSoft = Color(0xFF15332F), iris = Color(0xFFA99BFF),
    ok = Color(0xFF5BCB93), warn = Color(0xFFE3A743), bad = Color(0xFFF07A7A), info = Color(0xFF7FA6F5)
)

val LocalBlend = staticCompositionLocalOf { BlendLight }

/** Shortcut: `B.brand`, `B.ink` ... */
val B: Blend @Composable @ReadOnlyComposable get() = LocalBlend.current

/** Type scale. No letter-spacing anywhere: it breaks Arabic letter joining. */
object Ty {
    val display = TextStyle(fontSize = 44.sp, lineHeight = 52.sp, fontWeight = FontWeight.SemiBold, fontFeatureSettings = "tnum")
    val h1 = TextStyle(fontSize = 28.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
    val h2 = TextStyle(fontSize = 20.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold)
    val h3 = TextStyle(fontSize = 16.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold)
    val body = TextStyle(fontSize = 15.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal)
    val small = TextStyle(fontSize = 13.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal)
    val micro = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium)
}

private val BlendTypography = Typography(
    headlineSmall = Ty.h2, titleLarge = Ty.h2, titleMedium = Ty.h3,
    bodyLarge = Ty.body, bodyMedium = Ty.body, bodySmall = Ty.small,
    labelLarge = Ty.h3, labelMedium = Ty.small, labelSmall = Ty.micro
)

@Composable
fun statusColor(s: Int): Color = when (s) {
    St.ANSWERED -> B.ok
    St.NO_ANSWER -> B.warn
    St.FAILED -> B.bad
    St.CALLING -> B.info
    St.DONE -> B.brand
    else -> B.muted
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = when (Store.cfg.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val b = if (dark) BlendDark else BlendLight
    val scheme = if (dark) darkColorScheme(
        primary = b.brand, onPrimary = b.onBrand, primaryContainer = b.brandSoft, onPrimaryContainer = b.ink,
        secondary = b.iris, background = b.canvas, onBackground = b.ink, surface = b.surface, onSurface = b.ink,
        surfaceVariant = b.sunken, onSurfaceVariant = b.muted, outline = b.hairline, error = b.bad
    ) else lightColorScheme(
        primary = b.brand, onPrimary = b.onBrand, primaryContainer = b.brandSoft, onPrimaryContainer = b.ink,
        secondary = b.iris, background = b.canvas, onBackground = b.ink, surface = b.surface, onSurface = b.ink,
        surfaceVariant = b.sunken, onSurfaceVariant = b.muted, outline = b.hairline, error = b.bad
    )
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        w.statusBarColor = Color.Transparent.toArgb()
        w.navigationBarColor = Color.Transparent.toArgb()
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        val ic = WindowCompat.getInsetsController(w, view)
        ic.isAppearanceLightStatusBars = !dark
        ic.isAppearanceLightNavigationBars = !dark
    }
    CompositionLocalProvider(LocalBlend provides b) {
        MaterialTheme(
            colorScheme = scheme, typography = BlendTypography,
            shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp))
        ) {
            Surface(color = b.canvas, content = content)
        }
    }
}
