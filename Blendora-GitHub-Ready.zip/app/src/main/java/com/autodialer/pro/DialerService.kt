package com.autodialer.pro

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.CallLog
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import kotlin.random.Random

class DialerService : Service() {

    companion object {
        const val ACT_START = "start"
        const val ACT_STOP = "stop"
        const val ACT_PAUSE = "pause"
        const val ACT_RESUME = "resume"
        const val ACT_SKIP = "skip"

        fun send(ctx: Context, action: String, listId: String? = null) {
            val i = Intent(ctx, DialerService::class.java).setAction(action)
            if (listId != null) i.putExtra("list", listId)
            if (action == ACT_START) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
        }
    }

    private val S: Cfg get() = Store.cfg
    private val handler = Handler(Looper.getMainLooper())
    private val queue = kotlin.collections.ArrayDeque<String>()
    private val retriesLeft = HashMap<String, Int>()
    private var listId = ""
    private var curId: String? = null
    private var callStart = 0L
    private var offhookAt = 0L
    private var sawOffhook = false
    private var busy = false
    private var running = false
    private var paused = false
    private var loop = 1
    private lateinit var tm: TelephonyManager
    private lateinit var telecom: TelecomManager
    private var modernCb: Any? = null
    private var legacyCb: PhoneStateListener? = null
    private var wake: PowerManager.WakeLock? = null

    private val nextRunnable = Runnable { next() }
    private val noCallRunnable = Runnable { onNoCall() }
    private val hangupRunnable = Runnable { hangup() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_START -> {
                startFg()
                if (!running) startCampaign(intent?.getStringExtra("list") ?: "")
            }
            ACT_STOP -> if (running) finish("تم إيقاف الحملة") else stopSelf()
            ACT_PAUSE -> pause()
            ACT_RESUME -> resume()
            ACT_SKIP -> hangup()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------- campaign flow ----------
    private fun startCampaign(id: String) {
        val list = Store.lists.find { it.id == id }
        if (list == null || list.entries.isEmpty()) { finish("القائمة فارغة"); return }
        tm = getSystemService(TelephonyManager::class.java)
        telecom = getSystemService(TelecomManager::class.java)
        listId = id; running = true; paused = false; busy = false; loop = 1
        acquireWake()
        try { register() } catch (e: SecurityException) { finish("صلاحية حالة الهاتف غير ممنوحة"); return }
        val ids = buildQueue(list)
        if (ids.isEmpty()) { finish("لا توجد أرقام للتشغيل (الكل تم الرد عليه)"); return }
        val cd = S.startCountdown * 1000L
        upd(CampState(status = CS.RUNNING, listName = list.name, total = ids.size, loops = S.loops, loop = 1,
            message = "تبدأ الحملة بعد", nextAt = System.currentTimeMillis() + cd))
        handler.postDelayed(nextRunnable, cd)
    }

    private fun buildQueue(list: CallList): List<String> {
        var ids = list.entries
            .filter { !(S.skipAnswered && (it.status == St.ANSWERED || it.status == St.DONE)) }
            .map { it.id }
        if (S.shuffle) ids = ids.shuffled()
        val set = ids.toHashSet()
        Store.updateList(list.id) { l ->
            l.copy(entries = l.entries.map {
                if (it.id in set) it.copy(status = St.PENDING, attempts = 0, duration = 0) else it
            })
        }
        queue.clear(); queue.addAll(ids); retriesLeft.clear()
        return ids
    }

    private fun inWindow(): Boolean {
        if (!S.quietEnabled) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (S.quietFrom <= S.quietTo) h >= S.quietFrom && h < S.quietTo else h >= S.quietFrom || h < S.quietTo
    }

    private fun next() {
        if (!running || paused) return
        if (queue.isEmpty()) {
            if (loop < S.loops) {
                loop++
                val list = Store.lists.find { it.id == listId }
                val ids = if (list != null) buildQueue(list) else emptyList()
                if (ids.isEmpty()) { finish("اكتملت الحملة"); return }
                upd(Store.camp.copy(total = ids.size, done = 0, answered = 0, noAnswer = 0, failed = 0, loop = loop))
            } else { finish("اكتملت الحملة ✓"); return }
        }
        if (!inWindow()) {
            upd(Store.camp.copy(status = CS.WAITING, message = "خارج ساعات السماح — انتظار حتى ${S.quietFrom}:00", nextAt = 0))
            handler.postDelayed(nextRunnable, 30_000)
            return
        }
        place(queue.removeFirst())
    }

    private fun place(id: String) {
        val list = Store.lists.find { it.id == listId }
        val e = list?.entries?.find { it.id == id }
        if (e == null) { scheduleNext(); return }
        busy = true; curId = id; sawOffhook = false; callStart = System.currentTimeMillis()
        Store.updateEntry(listId, id) { it.copy(status = St.CALLING, attempts = it.attempts + 1) }
        upd(Store.camp.copy(status = CS.RUNNING, currentName = e.name, currentNumber = e.number,
            message = "جارٍ الاتصال…", nextAt = 0))
        try {
            val extras = Bundle()
            if (S.simIndex >= 0) runCatching {
                telecom.callCapablePhoneAccounts.getOrNull(S.simIndex)?.let {
                    extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it)
                }
            }
            telecom.placeCall(Uri.fromParts("tel", dialable(e.number, S.countryCode), null), extras)
            handler.postDelayed(noCallRunnable, 25_000)
        } catch (ex: SecurityException) {
            finish("صلاحية الاتصال غير ممنوحة")
        }
    }

    private fun onState(state: Int) {
        if (!running) return
        if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
            if (curId != null && !sawOffhook) {
                sawOffhook = true
                offhookAt = System.currentTimeMillis()
                handler.removeCallbacks(noCallRunnable)
                if (S.maxCallSec > 0) handler.postDelayed(hangupRunnable, S.maxCallSec * 1000L)
            }
        } else if (state == TelephonyManager.CALL_STATE_IDLE && sawOffhook && curId != null) {
            sawOffhook = false
            handler.removeCallbacks(hangupRunnable)
            val id = curId!!
            curId = null
            val dur = ((System.currentTimeMillis() - offhookAt) / 1000).toInt()
            val since = callStart
            handler.postDelayed({ evaluate(id, since, dur, 0) }, 1500)
        }
    }

    private fun onNoCall() {
        val id = curId ?: return
        if (sawOffhook) return
        curId = null
        record(id, St.FAILED, 0)
    }

    private fun evaluate(id: String, since: Long, dur: Int, tries: Int) {
        if (!running) return
        if (S.useCallLog && has(Manifest.permission.READ_CALL_LOG)) {
            val d = queryLog(since)
            if (d == null && tries < 2) {
                handler.postDelayed({ evaluate(id, since, dur, tries + 1) }, 1500)
                return
            }
            if (d != null) { record(id, if (d > 0) St.ANSWERED else St.NO_ANSWER, d); return }
        }
        record(id, St.DONE, dur)
    }

    private fun queryLog(since: Long): Int? = try {
        contentResolver.query(
            CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.DURATION),
            "${CallLog.Calls.DATE} >= ? AND ${CallLog.Calls.TYPE} = ?",
            arrayOf(since.toString(), CallLog.Calls.OUTGOING_TYPE.toString()),
            "${CallLog.Calls.DATE} ASC"
        )?.use { c -> if (c.moveToFirst()) c.getInt(0) else null }
    } catch (e: Exception) { null }

    private fun record(id: String, status: Int, dur: Int) {
        busy = false
        val list = Store.lists.find { it.id == listId }
        if (list == null) { scheduleNext(); return }
        val e = list.entries.find { it.id == id }
        Store.updateEntry(listId, id) { it.copy(status = status, duration = dur) }
        if (e != null) Store.addLog(LogItem(System.currentTimeMillis(), list.name, e.name, e.number, status, dur, e.attempts))
        val unanswered = status == St.NO_ANSWER || status == St.FAILED
        val left = retriesLeft.getOrPut(id) { S.retries }
        val r = Store.camp
        if (unanswered && left > 0) {
            retriesLeft[id] = left - 1
            queue.addLast(id)
            upd(r.copy(message = "سيُعاد الاتصال بهذا الرقم لاحقًا"))
        } else {
            upd(r.copy(
                done = r.done + 1,
                answered = r.answered + if (!unanswered) 1 else 0,
                noAnswer = r.noAnswer + if (status == St.NO_ANSWER) 1 else 0,
                failed = r.failed + if (status == St.FAILED) 1 else 0
            ))
        }
        scheduleNext()
    }

    private fun scheduleNext() {
        if (!running) return
        if (paused) { upd(Store.camp.copy(status = CS.PAUSED, message = "متوقفة مؤقتًا", nextAt = 0)); return }
        if (queue.isEmpty()) { handler.post(nextRunnable); return }
        val lo = S.delaySec
        val hi = maxOf(lo, S.delayMaxSec)
        val sec = if (S.randomDelay) Random.nextInt(lo, hi + 1) else lo
        upd(Store.camp.copy(status = CS.RUNNING, currentName = "", currentNumber = "",
            message = "الاتصال التالي بعد", nextAt = System.currentTimeMillis() + sec * 1000L))
        handler.postDelayed(nextRunnable, sec * 1000L)
    }

    private fun pause() {
        if (!running || paused) return
        paused = true
        handler.removeCallbacks(nextRunnable)
        upd(Store.camp.copy(status = CS.PAUSED, message = "متوقفة مؤقتًا", nextAt = 0))
    }

    private fun resume() {
        if (!running || !paused) return
        paused = false
        upd(Store.camp.copy(status = CS.RUNNING, message = "استئناف…"))
        if (!busy) handler.postDelayed(nextRunnable, 1000)
    }

    @Suppress("DEPRECATION")
    private fun hangup() {
        try {
            if (Build.VERSION.SDK_INT >= 28 && has(Manifest.permission.ANSWER_PHONE_CALLS)) telecom.endCall()
        } catch (e: Exception) {}
    }

    private fun finish(msg: String) {
        if (::telecom.isInitialized && (curId != null || sawOffhook)) hangup()
        running = false; paused = false; busy = false; curId = null; sawOffhook = false
        handler.removeCallbacksAndMessages(null)
        unregister(); releaseWake()
        if (listId.isNotEmpty()) {
            Store.updateList(listId) { l ->
                l.copy(entries = l.entries.map { if (it.status == St.CALLING) it.copy(status = St.PENDING) else it })
            }
        }
        Store.camp = Store.camp.copy(status = CS.FINISHED, message = msg, currentName = "", currentNumber = "", nextAt = 0)
        if (S.vibrateOnFinish) buzz()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- telephony callbacks ----------
    @RequiresApi(31)
    private inner class Cb : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) = onState(state)
    }

    @Suppress("DEPRECATION")
    private fun register() {
        unregister()
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = Cb()
            modernCb = cb
            tm.registerTelephonyCallback(mainExecutor, cb)
        } else {
            val l = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) { onState(state) }
            }
            legacyCb = l
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    @Suppress("DEPRECATION")
    private fun unregister() {
        if (!::tm.isInitialized) return
        try {
            if (Build.VERSION.SDK_INT >= 31) (modernCb as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            else legacyCb?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (e: Exception) {}
        modernCb = null; legacyCb = null
    }

    // ---------- helpers ----------
    private fun acquireWake() {
        releaseWake()
        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "autodialer:run").also { it.acquire(8 * 60 * 60 * 1000L) }
    }

    private fun releaseWake() {
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    private fun buzz() {
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {}
    }

    private fun upd(c: CampState) {
        Store.camp = c
        if (running) getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    private fun pi(action: String, req: Int) = PendingIntent.getService(
        this, req, Intent(this, DialerService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun notif(): Notification {
        val r = Store.camp
        val cur = r.currentName.ifEmpty { r.currentNumber }
        val b = NotificationCompat.Builder(this, "dialer")
            .setSmallIcon(R.drawable.ic_stat_blendora).setColor(0xFF17655F.toInt())
            .setContentTitle("حملة: ${r.listName}")
            .setContentText(if (cur.isNotEmpty()) "${r.done}/${r.total} • $cur" else "${r.done}/${r.total} • ${r.message}")
            .setOngoing(true).setOnlyAlertOnce(true)
            .setProgress(r.total, r.done, false)
            .setContentIntent(PendingIntent.getActivity(this, 9, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        if (paused) b.addAction(0, "استئناف", pi(ACT_RESUME, 1)) else b.addAction(0, "إيقاف مؤقت", pi(ACT_PAUSE, 2))
        b.addAction(0, "إيقاف", pi(ACT_STOP, 3))
        return b.build()
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("dialer", "الحملة", NotificationManager.IMPORTANCE_LOW))
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, notif(), type)
    }

    override fun onDestroy() {
        if (running) {
            running = false
            Store.camp = Store.camp.copy(status = CS.FINISHED, message = "توقفت الخدمة")
        }
        handler.removeCallbacksAndMessages(null)
        unregister(); releaseWake()
        super.onDestroy()
    }
}
